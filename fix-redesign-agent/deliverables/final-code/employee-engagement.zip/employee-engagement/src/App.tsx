import { PreviewBar, PreviewNotes } from './runtime/PreviewChrome';
import { ScrollEffects } from './runtime/ScrollEffectsHost';
import SectionWhenPeopleFeelHeardTheyPerformeffectively from './generated/sections/SectionWhenPeopleFeelHeardTheyPerformeffectively';
import SectionEmployeeExperienceDashboard from './generated/sections/SectionEmployeeExperienceDashboard';
import SectionUseRealFeedbackFromRealEmployeesToUnderstandWhatDrivesEngagementAndActWithConfidenceB from './generated/sections/SectionUseRealFeedbackFromRealEmployeesToUnderstandWhatDrivesEngagementAndActWithConfidenceB';
import SectionWhatsImpactingYourEmployees from './generated/sections/SectionWhatsImpactingYourEmployees';
import SectionHowWeUnderstandYourPeople from './generated/sections/SectionHowWeUnderstandYourPeople';
import SectionWhatSetsUsApart from './generated/sections/SectionWhatSetsUsApart';
import SectionOurImpact from './generated/sections/SectionOurImpact';
import SectionWhatOurClientsSay from './generated/sections/SectionWhatOurClientsSay';
import SectionFaqs from './generated/sections/SectionFaqs';
import SectionOurResources from './generated/sections/SectionOurResources';
import SectionExploreOtherSurveys from './generated/sections/SectionExploreOtherSurveys';

export default function App() {
  return (
    <>
      <PreviewBar />
      <ScrollEffects />
      <main>
        <SectionWhenPeopleFeelHeardTheyPerformeffectively />
        <SectionEmployeeExperienceDashboard />
        <SectionUseRealFeedbackFromRealEmployeesToUnderstandWhatDrivesEngagementAndActWithConfidenceB />
        <SectionWhatsImpactingYourEmployees />
        <SectionHowWeUnderstandYourPeople />
        <SectionWhatSetsUsApart />
        <SectionOurImpact />
        <SectionWhatOurClientsSay />
        <SectionFaqs />
        <SectionOurResources />
        <SectionExploreOtherSurveys />
      </main>
      <PreviewNotes />
    </>
  );
}
