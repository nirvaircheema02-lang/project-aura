export const htmlAttrs: Record<string, string> = {"lang":"en","class":"__variable_acff56 __variable_3a8b9c __variable_0fb77e __variable_0a13bd __variable_0d27cc "};
export const bodyAttrs: Record<string, string> = {};
