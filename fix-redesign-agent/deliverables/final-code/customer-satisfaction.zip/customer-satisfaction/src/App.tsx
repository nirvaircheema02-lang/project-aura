import { PreviewBar, PreviewNotes } from './runtime/PreviewChrome';
import { ScrollEffects } from './runtime/ScrollEffectsHost';
import SectionKnowWhatYourCustomersReallyFeelNotJustWhatTheySay from './generated/sections/SectionKnowWhatYourCustomersReallyFeelNotJustWhatTheySay';
import SectionCustomerSatisfactionDashboard from './generated/sections/SectionCustomerSatisfactionDashboard';
import SectionUseRealFeedbackFromRealAudiencesToUnderstandWhatDrivesDecisionsAndActWithConfidence from './generated/sections/SectionUseRealFeedbackFromRealAudiencesToUnderstandWhatDrivesDecisionsAndActWithConfidence';
import SectionWhatsImpactingYourCustomer from './generated/sections/SectionWhatsImpactingYourCustomer';
import SectionHowWeHelpYouUnderstandCustomersBetter from './generated/sections/SectionHowWeHelpYouUnderstandCustomersBetter';
import SectionWhatMakesOurWayDifferent from './generated/sections/SectionWhatMakesOurWayDifferent';
import SectionOurImpact from './generated/sections/SectionOurImpact';
import SectionWhatOurClientsSay from './generated/sections/SectionWhatOurClientsSay';
import SectionFaqs from './generated/sections/SectionFaqs';
import SectionOurResources from './generated/sections/SectionOurResources';
import SectionExploreOtherSurveys from './generated/sections/SectionExploreOtherSurveys';

export default function App() {
  return (
    <>
      <PreviewBar />
      <ScrollEffects />
      <main>
        <SectionKnowWhatYourCustomersReallyFeelNotJustWhatTheySay />
        <SectionCustomerSatisfactionDashboard />
        <SectionUseRealFeedbackFromRealAudiencesToUnderstandWhatDrivesDecisionsAndActWithConfidence />
        <SectionWhatsImpactingYourCustomer />
        <SectionHowWeHelpYouUnderstandCustomersBetter />
        <SectionWhatMakesOurWayDifferent />
        <SectionOurImpact />
        <SectionWhatOurClientsSay />
        <SectionFaqs />
        <SectionOurResources />
        <SectionExploreOtherSurveys />
      </main>
      <PreviewNotes />
    </>
  );
}
