# Run notes (hand-written, not generated)

Run: `customer-satisfaction-survey-page-audit-v4-redesign-20261027-111641` · source audit run `customer-satisfaction-survey-page-audit-v4` · Selected Sections.
These notes are written by hand after the pipeline finished. The pipeline does not read or overwrite this file; `redesign/PREVIEW.md` and `redesign/finding-accounting.md` are generated and remain the verified record.

## Customer Satisfaction Dashboard — "View Sample Dashboard" CTA (finding `e8be442c192c7e32185051dedb39d60f`)

**Decision (user, chat, 2026-10-28):** keep the DS `Button` as `variant="secondary"`; only record the difference from the audit in the run report.

| | Audit (DS match) | Preview |
|---|---|---|
| Component | `Button` · `ghost` · `md` · light | `Button` · `secondary` · `md` · light · `animatedArrow` |
| background-color | transparent (expected) | white (`rgb(255, 255, 255)`) — fails the audit target |
| padding-left / padding-right | 0 (expected) | 28px (`--button-px-md`) — fails the audit target |
| height / font-size / weight / letter-spacing / display | 48px / 1rem / 500 / 0.0875px / inline-flex | same — verified against the audit |

- Reported status in `finding-accounting.md`: **partially-verified** (5 of 8 targets verified, 3 not matching). It is **not** claimed fixed.
- The variant differs from the audit's DS match (`ghost`); the audit's background and padding targets are not met by `secondary`. Accepted by the user as a deliberate difference.
- Never the black `primary` variant.
- Not covered by this note: the original link had an empty `href=""`, so the preview renders a `<button>` with no destination.
- Other differences from the original page: text 12px → 16px, 20px → 28px horizontal padding (DS `md` tokens).
- Not re-measured after this note; the figures above come from the preview served at the G2 pause (verification run `FAIL`, 2026-10-27).
