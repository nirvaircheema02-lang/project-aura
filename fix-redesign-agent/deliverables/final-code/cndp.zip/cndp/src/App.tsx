import { PreviewBar, PreviewNotes } from './runtime/PreviewChrome';
import { ScrollEffects } from './runtime/ScrollEffectsHost';
import SectionWhatYourCustomersWantIsnTHiddenItSUnheard from './generated/sections/SectionWhatYourCustomersWantIsnTHiddenItSUnheard';
import SectionCustomerNeedsPainPointsDashboard from './generated/sections/SectionCustomerNeedsPainPointsDashboard';
import SectionUseRealFeedbackFromRealAudiencesToUnderstandWhatDrivesDecisionsAndActWithConfidence from './generated/sections/SectionUseRealFeedbackFromRealAudiencesToUnderstandWhatDrivesDecisionsAndActWithConfidence';
import SectionHowWeUnderstandWhatYourCustomersReallyWant from './generated/sections/SectionHowWeUnderstandWhatYourCustomersReallyWant';
import SectionWhatMakesOurWayDifferent from './generated/sections/SectionWhatMakesOurWayDifferent';
import SectionOurImpact from './generated/sections/SectionOurImpact';
import SectionWhatOurClientsSay from './generated/sections/SectionWhatOurClientsSay';
import SectionFaqs from './generated/sections/SectionFaqs';
import SectionOurResources from './generated/sections/SectionOurResources';
import SectionExploreOtherSurveys from './generated/sections/SectionExploreOtherSurveys';

export default function App() {
  return (
    <>
      <PreviewBar />
      <ScrollEffects />
      <main>
        <SectionWhatYourCustomersWantIsnTHiddenItSUnheard />
        <SectionCustomerNeedsPainPointsDashboard />
        <SectionUseRealFeedbackFromRealAudiencesToUnderstandWhatDrivesDecisionsAndActWithConfidence />
        <SectionHowWeUnderstandWhatYourCustomersReallyWant />
        <SectionWhatMakesOurWayDifferent />
        <SectionOurImpact />
        <SectionWhatOurClientsSay />
        <SectionFaqs />
        <SectionOurResources />
        <SectionExploreOtherSurveys />
      </main>
      <PreviewNotes />
    </>
  );
}
