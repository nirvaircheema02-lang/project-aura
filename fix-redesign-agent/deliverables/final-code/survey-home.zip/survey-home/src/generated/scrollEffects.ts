import type { ScrollEffect } from '../runtime/scrollEffects';
export const scrollEffects: ScrollEffect[] = [];
