import { PreviewBar, PreviewNotes } from './runtime/PreviewChrome';
import { ScrollEffects } from './runtime/ScrollEffectsHost';
import SectionSurveyConsultingThatShapesCriticalDecisions from './generated/sections/SectionSurveyConsultingThatShapesCriticalDecisions';
import SectionFindYourSurveySSweetSpot from './generated/sections/SectionFindYourSurveySSweetSpot';
import SectionBecauseEveryVoiceDeservesToBeHeard from './generated/sections/SectionBecauseEveryVoiceDeservesToBeHeard';
import SectionReachAnyoneAnywhereWithPurpose from './generated/sections/SectionReachAnyoneAnywhereWithPurpose';
import SectionOurApproach from './generated/sections/SectionOurApproach';
import SectionOurDifferentiatorsWhatDistinguishesOurSurveyAndInsightCapabilities from './generated/sections/SectionOurDifferentiatorsWhatDistinguishesOurSurveyAndInsightCapabilities';
import SectionWhatOurClientsSay from './generated/sections/SectionWhatOurClientsSay';
import SectionCoverageAcrossAudiences from './generated/sections/SectionCoverageAcrossAudiences';
import SectionUseRealFeedbackFromRealAudiencesToUnderstandWhatDrivesDecisionsAndActWithConfidence from './generated/sections/SectionUseRealFeedbackFromRealAudiencesToUnderstandWhatDrivesDecisionsAndActWithConfidence';
import SectionOurImpact from './generated/sections/SectionOurImpact';
import SectionFaqs from './generated/sections/SectionFaqs';
import SectionExploreOtherSurveys from './generated/sections/SectionExploreOtherSurveys';

export default function App() {
  return (
    <>
      <PreviewBar />
      <ScrollEffects />
      <main>
        <SectionSurveyConsultingThatShapesCriticalDecisions />
        <SectionFindYourSurveySSweetSpot />
        <SectionBecauseEveryVoiceDeservesToBeHeard />
        <SectionReachAnyoneAnywhereWithPurpose />
        <SectionOurApproach />
        <SectionOurDifferentiatorsWhatDistinguishesOurSurveyAndInsightCapabilities />
        <SectionWhatOurClientsSay />
        <SectionCoverageAcrossAudiences />
        <SectionUseRealFeedbackFromRealAudiencesToUnderstandWhatDrivesDecisionsAndActWithConfidence />
        <SectionOurImpact />
        <SectionFaqs />
        <SectionExploreOtherSurveys />
      </main>
      <PreviewNotes />
    </>
  );
}
